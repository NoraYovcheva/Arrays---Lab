﻿using System;
using System.Linq;

namespace _04.ReverseArrayOfStrings
{
    class Program
    {
        static void Main(string[] args)
        {
            var items = Console.ReadLine().Split(' ').ToArray();
            for (int i = 0; i < items.Length / 2; i++)
            {
                var oldElement = items[i];
                items[i] = items[items.Length - 1 - i];
                items[items.Length - 1 - i] = oldElement;
            }

            Console.WriteLine(string.Join(" ", items));

            //var letter = Console.ReadLine()
            //    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
            //    .ToArray();

            //for (int i = 0; i < letter.Length / 2; i++)
            //{
            //    letter[i] = Console.ReadLine();
            //}
            //Console.WriteLine(string.Join(' ', letter.Reverse()));
        }
    }
}
